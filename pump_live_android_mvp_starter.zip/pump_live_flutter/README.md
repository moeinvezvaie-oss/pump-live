# Pump Live — Android MVP starter

این نسخه، اسکلت اولیه رابط کاربری Pump Live را با Flutter آماده می‌کند.

## اجرا
1. Flutter SDK را نصب کنید.
2. Android Studio را نصب کنید.
3. این پوشه را در Android Studio باز کنید.
4. در Terminal پروژه اجرا کنید:
   flutter pub get
   flutter run

## وضعیت فعلی
- رابط فارسی و RTL
- صفحه Home
- جستجو
- فیلترهای اولیه
- نقشه نمایشی اولیه
- نمایش وضعیت شلوغی
- موقعیت کاربر به صورت نمایشی
- Bottom Navigation

## مرحله بعد
اتصال نقشه واقعی، GPS، دیتابیس پمپ‌ها و ثبت گزارش کاربران.
