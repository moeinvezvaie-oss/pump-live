import 'package:flutter/material.dart';

void main() {
  runApp(const PumpLiveApp());
}

class PumpLiveApp extends StatelessWidget {
  const PumpLiveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pump Live',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00A99D),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF8FAFA),
      ),
      home: const HomeScreen(),
    );
  }
}

enum Crowd { quiet, medium, busy, veryBusy }

class Station {
  final String name;
  final String address;
  final double distance;
  final Crowd crowd;

  const Station({
    required this.name,
    required this.address,
    required this.distance,
    required this.crowd,
  });
}

const stations = [
  Station(
    name: 'پمپ‌بنزین جهان کودک',
    address: 'خیابان شهید بهشتی، بالاتر از ظفر',
    distance: 1.2,
    crowd: Crowd.veryBusy,
  ),
  Station(
    name: 'پمپ‌بنزین یادگار امام',
    address: 'خیابان یادگار امام',
    distance: 2.4,
    crowd: Crowd.busy,
  ),
  Station(
    name: 'پمپ‌بنزین آفریقا',
    address: 'خیابان آفریقا',
    distance: 3.1,
    crowd: Crowd.medium,
  ),
  Station(
    name: 'پمپ‌بنزین ونک',
    address: 'میدان ونک',
    distance: 4.7,
    crowd: Crowd.quiet,
  ),
];

String crowdLabel(Crowd crowd) {
  switch (crowd) {
    case Crowd.quiet:
      return 'خلوت';
    case Crowd.medium:
      return 'نسبتاً شلوغ';
    case Crowd.busy:
      return 'شلوغ';
    case Crowd.veryBusy:
      return 'خیلی شلوغ';
  }
}

Color crowdColor(Crowd crowd) {
  switch (crowd) {
    case Crowd.quiet:
      return const Color(0xFF19B66A);
    case Crowd.medium:
      return const Color(0xFFFFC107);
    case Crowd.busy:
      return const Color(0xFFFF8A00);
    case Crowd.veryBusy:
      return const Color(0xFFE53935);
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedTab = 0;
  Crowd? selectedCrowd;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          titleSpacing: 20,
          title: const Text(
            'نقشه',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20),
          ),
          leading: IconButton(
            icon: const Icon(Icons.menu_rounded),
            onPressed: () {},
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.notifications_none_rounded),
              onPressed: () {},
            ),
            const SizedBox(width: 8),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              _searchAndFilters(),
              Expanded(child: _mapArea()),
              _stationSheet(),
            ],
          ),
        ),
        bottomNavigationBar: _bottomBar(),
      ),
    );
  }

  Widget _searchAndFilters() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
      child: Column(
        children: [
          TextField(
            decoration: InputDecoration(
              hintText: 'جستجوی پمپ‌بنزین یا منطقه',
              prefixIcon: const Icon(Icons.search_rounded),
              filled: true,
              fillColor: const Color(0xFFF5F7F7),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              _filterButton(
                label: 'فیلتر',
                icon: Icons.tune_rounded,
                onTap: () {},
              ),
              const SizedBox(width: 8),
              _filterButton(
                label: 'همه سوخت‌ها',
                icon: Icons.keyboard_arrow_down_rounded,
                onTap: () {},
              ),
              const SizedBox(width: 8),
              Expanded(
                child: FilledButton.icon(
                  onPressed: () {
                    setState(() {
                      selectedCrowd = selectedCrowd == Crowd.quiet
                          ? null
                          : Crowd.quiet;
                    });
                  },
                  icon: const Icon(Icons.people_alt_outlined, size: 18),
                  label: const Text('بر اساس شلوغی'),
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFF00A99D),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _filterButton({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 18),
      label: Text(label),
      style: OutlinedButton.styleFrom(
        foregroundColor: const Color(0xFF263238),
        side: const BorderSide(color: Color(0xFFE0E5E5)),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
    );
  }

  Widget _mapArea() {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            Color(0xFFE8F2ED),
            Color(0xFFF5F1E7),
            Color(0xFFE7EFF5),
          ],
        ),
      ),
      child: Stack(
        children: [
          CustomPaint(size: Size.infinite, painter: _MapGridPainter()),
          ...stations.asMap().entries.map((entry) {
            final positions = [
              const Alignment(-0.55, -0.45),
              const Alignment(0.48, -0.25),
              const Alignment(-0.35, 0.28),
              const Alignment(0.55, 0.48),
            ];
            return Align(
              alignment: positions[entry.key],
              child: _mapMarker(entry.value),
            );
          }),
          const Align(
            alignment: Alignment.center,
            child: _userLocation(),
          ),
          Positioned(
            left: 16,
            bottom: 16,
            child: FloatingActionButton.small(
              heroTag: 'location',
              backgroundColor: Colors.white,
              foregroundColor: const Color(0xFF00A99D),
              onPressed: () {},
              child: const Icon(Icons.my_location_rounded),
            ),
          ),
        ],
      ),
    );
  }

  Widget _mapMarker(Station station) {
    final color = crowdColor(station.crowd);
    return GestureDetector(
      onTap: () {},
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 3),
          boxShadow: const [
            BoxShadow(
              blurRadius: 8,
              color: Color(0x33000000),
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: const Icon(Icons.local_gas_station_rounded,
            color: Colors.white, size: 22),
      ),
    );
  }

  static Widget _userLocation() {
    return Container(
      width: 28,
      height: 28,
      decoration: BoxDecoration(
        color: const Color(0xFF1976D2),
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 4),
        boxShadow: const [
          BoxShadow(
            color: Color(0x441976D2),
            blurRadius: 18,
            spreadRadius: 8,
          ),
        ],
      ),
    );
  }

  Widget _stationSheet() {
    final station = stations.first;
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 16),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        boxShadow: [
          BoxShadow(
            color: Color(0x22000000),
            blurRadius: 14,
            offset: Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  station.name,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  station.address,
                  style: const TextStyle(color: Color(0xFF687477)),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.people_alt_rounded,
                        size: 17, color: crowdColor(station.crowd)),
                    const SizedBox(width: 4),
                    Text(
                      crowdLabel(station.crowd),
                      style: TextStyle(
                        color: crowdColor(station.crowd),
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Text('${station.distance} کیلومتر',
                        style: const TextStyle(color: Color(0xFF687477))),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          CircleAvatar(
            radius: 25,
            backgroundColor: const Color(0xFFE6F7F5),
            child: const Icon(Icons.navigation_rounded,
                color: Color(0xFF00A99D)),
          ),
        ],
      ),
    );
  }

  Widget _bottomBar() {
    return NavigationBar(
      selectedIndex: selectedTab,
      onDestinationSelected: (index) {
        setState(() => selectedTab = index);
      },
      backgroundColor: Colors.white,
      indicatorColor: const Color(0xFFDDF6F3),
      destinations: const [
        NavigationDestination(
          icon: Icon(Icons.home_outlined),
          selectedIcon: Icon(Icons.home_rounded),
          label: 'خانه',
        ),
        NavigationDestination(
          icon: Icon(Icons.map_outlined),
          selectedIcon: Icon(Icons.map_rounded),
          label: 'نقشه',
        ),
        NavigationDestination(
          icon: Icon(Icons.add_circle_outline_rounded, size: 30),
          selectedIcon: Icon(Icons.add_circle_rounded, size: 30),
          label: 'گزارش',
        ),
        NavigationDestination(
          icon: Icon(Icons.favorite_border_rounded),
          selectedIcon: Icon(Icons.favorite_rounded),
          label: 'علاقه‌مندی‌ها',
        ),
        NavigationDestination(
          icon: Icon(Icons.person_outline_rounded),
          selectedIcon: Icon(Icons.person_rounded),
          label: 'حساب کاربری',
        ),
      ],
    );
  }
}

class _MapGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0x5595A9A9)
      ..strokeWidth = 1;

    const gap = 58.0;
    for (double x = 0; x < size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x + 120, size.height), paint);
    }
    for (double y = 0; y < size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y + 90), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
