# Pump Live v2
Real-map Android MVP:
- OpenStreetMap real tiles
- GPS/current location
- 6 real Tehran gas-station locations in Districts 1 and 3
- Dynamic distance from user
- External navigation button
- Crowd colors are DEMO data until backend/user reports are added
