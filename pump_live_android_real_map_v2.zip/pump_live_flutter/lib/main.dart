import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const PumpLiveApp());
}

class PumpLiveApp extends StatelessWidget {
  const PumpLiveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'پمپ لایو',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00A99D),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F9F9),
      ),
      home: const PumpLiveMapScreen(),
    );
  }
}

enum CrowdLevel { quiet, medium, busy, veryBusy }

class Station {
  final String name;
  final String district;
  final String address;
  final double lat;
  final double lon;
  final CrowdLevel crowd;
  final String sourceNote;

  const Station({
    required this.name,
    required this.district,
    required this.address,
    required this.lat,
    required this.lon,
    required this.crowd,
    required this.sourceNote,
  });
}

const stations = <Station>[
  Station(
    name: 'جایگاه ۱۳۴ اقدسیه',
    district: 'منطقه ۱',
    address: 'پاسداران شمالی، پایین‌تر از سه‌راه اقدسیه',
    lat: 35.802296,
    lon: 51.473480,
    crowd: CrowdLevel.medium,
    sourceNote: 'وضعیت شلوغی فعلاً آزمایشی است',
  ),
  Station(
    name: 'جایگاه ۱۳۹ باغ فردوس',
    district: 'منطقه ۱',
    address: 'خیابان ولیعصر، محدوده باغ فردوس',
    lat: 35.805839,
    lon: 51.422919,
    crowd: CrowdLevel.busy,
    sourceNote: 'وضعیت شلوغی فعلاً آزمایشی است',
  ),
  Station(
    name: 'جایگاه ۱۴۸ ولنجک',
    district: 'منطقه ۱',
    address: 'ولنجک، شمال تهران',
    lat: 35.792859,
    lon: 51.406328,
    crowd: CrowdLevel.quiet,
    sourceNote: 'وضعیت شلوغی فعلاً آزمایشی است',
  ),
  Station(
    name: 'پمپ بنزین آفریقا',
    district: 'منطقه ۳',
    address: 'بلوار نلسون ماندلا (آفریقا)',
    lat: 35.769938,
    lon: 51.420563,
    crowd: CrowdLevel.veryBusy,
    sourceNote: 'وضعیت شلوغی فعلاً آزمایشی است',
  ),
  Station(
    name: 'پمپ بنزین پارک شریعتی',
    district: 'منطقه ۳',
    address: 'خیابان شریعتی',
    lat: 35.748438,
    lon: 51.448938,
    crowd: CrowdLevel.medium,
    sourceNote: 'وضعیت شلوغی فعلاً آزمایشی است',
  ),
  Station(
    name: 'پمپ بنزین پاسداران',
    district: 'منطقه ۳',
    address: 'پاسداران',
    lat: 35.775188,
    lon: 51.463813,
    crowd: CrowdLevel.busy,
    sourceNote: 'وضعیت شلوغی فعلاً آزمایشی است',
  ),
];

class PumpLiveMapScreen extends StatefulWidget {
  const PumpLiveMapScreen({super.key});

  @override
  State<PumpLiveMapScreen> createState() => _PumpLiveMapScreenState();
}

class _PumpLiveMapScreenState extends State<PumpLiveMapScreen> {
  final MapController _mapController = MapController();
  Position? _position;
  Station? _selected;
  String _locationStatus = 'برای نمایش فاصله، موقعیت مکانی را فعال کنید';
  bool _locating = false;

  static const LatLng _tehranNorth = LatLng(35.785, 51.435);

  @override
  void initState() {
    super.initState();
    Future.microtask(_locateMe);
  }

  Future<void> _locateMe() async {
    if (_locating) return;
    setState(() => _locating = true);

    try {
      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) {
        setState(() {
          _locationStatus = 'GPS گوشی خاموش است';
          _locating = false;
        });
        return;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        setState(() {
          _locationStatus = 'اجازه دسترسی به موقعیت داده نشده';
          _locating = false;
        });
        return;
      }

      final p = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );

      if (!mounted) return;
      setState(() {
        _position = p;
        _locationStatus = 'موقعیت شما پیدا شد';
        _locating = false;
      });
      _mapController.move(LatLng(p.latitude, p.longitude), 14.5);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _locationStatus = 'دریافت موقعیت ممکن نشد؛ دوباره تلاش کنید';
        _locating = false;
      });
    }
  }

  String _crowdText(CrowdLevel level) {
    switch (level) {
      case CrowdLevel.quiet:
        return 'خلوت';
      case CrowdLevel.medium:
        return 'متوسط';
      case CrowdLevel.busy:
        return 'شلوغ';
      case CrowdLevel.veryBusy:
        return 'خیلی شلوغ';
    }
  }

  Color _crowdColor(CrowdLevel level) {
    switch (level) {
      case CrowdLevel.quiet:
        return const Color(0xFF19B66A);
      case CrowdLevel.medium:
        return const Color(0xFFFFC107);
      case CrowdLevel.busy:
        return const Color(0xFFFF8A00);
      case CrowdLevel.veryBusy:
        return const Color(0xFFE53935);
    }
  }

  String _distanceText(Station station) {
    if (_position == null) return 'فاصله نامشخص';
    final meters = Geolocator.distanceBetween(
      _position!.latitude,
      _position!.longitude,
      station.lat,
      station.lon,
    );
    if (meters < 1000) return '${meters.round()} متر';
    return '${(meters / 1000).toStringAsFixed(1)} کیلومتر';
  }

  Future<void> _navigateTo(Station station) async {
    final geo = Uri.parse(
      'geo:${station.lat},${station.lon}?q=${station.lat},${station.lon}(${Uri.encodeComponent(station.name)})',
    );
    final web = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=${station.lat},${station.lon}',
    );
    if (await canLaunchUrl(geo)) {
      await launchUrl(geo);
    } else {
      await launchUrl(web, mode: LaunchMode.externalApplication);
    }
  }

  void _selectStation(Station station) {
    setState(() => _selected = station);
    _mapController.move(LatLng(station.lat, station.lon), 15.5);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'پمپ لایو',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          centerTitle: true,
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
        ),
        body: Stack(
          children: [
            FlutterMap(
              mapController: _mapController,
              options: MapOptions(
                initialCenter: _tehranNorth,
                initialZoom: 12.5,
                onTap: (_, __) => setState(() => _selected = null),
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.pumplive.app',
                  maxZoom: 19,
                ),
                MarkerLayer(
                  markers: [
                    for (final s in stations)
                      Marker(
                        point: LatLng(s.lat, s.lon),
                        width: 54,
                        height: 54,
                        child: GestureDetector(
                          onTap: () => _selectStation(s),
                          child: Container(
                            decoration: BoxDecoration(
                              color: _crowdColor(s.crowd),
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 3),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x33000000),
                                  blurRadius: 8,
                                  offset: Offset(0, 3),
                                )
                              ],
                            ),
                            child: const Icon(
                              Icons.local_gas_station_rounded,
                              color: Colors.white,
                              size: 26,
                            ),
                          ),
                        ),
                      ),
                    if (_position != null)
                      Marker(
                        point: LatLng(
                          _position!.latitude,
                          _position!.longitude,
                        ),
                        width: 34,
                        height: 34,
                        child: Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFF1976D2),
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 4),
                            boxShadow: const [
                              BoxShadow(
                                color: Color(0x441976D2),
                                blurRadius: 12,
                              )
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
                RichAttributionWidget(
                  attributions: const [
                    TextSourceAttribution('OpenStreetMap contributors'),
                  ],
                ),
              ],
            ),

            Positioned(
              top: 12,
              right: 12,
              left: 12,
              child: _topCard(),
            ),

            Positioned(
              left: 16,
              bottom: _selected == null ? 24 : 210,
              child: FloatingActionButton(
                heroTag: 'gps',
                onPressed: _locateMe,
                backgroundColor: Colors.white,
                foregroundColor: const Color(0xFF00A99D),
                child: _locating
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2.5),
                      )
                    : const Icon(Icons.my_location_rounded),
              ),
            ),

            if (_selected != null)
              Positioned(
                right: 12,
                left: 12,
                bottom: 12,
                child: _stationCard(_selected!),
              ),
          ],
        ),
      ),
    );
  }

  Widget _topCard() {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                const Icon(Icons.map_rounded, color: Color(0xFF00A99D)),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text(
                    'جایگاه‌های منطقه ۱ و ۳ تهران',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
                Text(
                  '${stations.length} جایگاه',
                  style: const TextStyle(
                    color: Color(0xFF667477),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                const Icon(Icons.location_on_outlined, size: 17),
                const SizedBox(width: 5),
                Expanded(
                  child: Text(
                    _locationStatus,
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            const Text(
              'نقشه و GPS واقعی است؛ رنگ شلوغی فعلاً داده آزمایشی دارد.',
              style: TextStyle(
                color: Color(0xFF8A5A00),
                fontSize: 11.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stationCard(Station station) {
    final color = _crowdColor(station.crowd);
    return Card(
      elevation: 8,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: color,
                  child: const Icon(
                    Icons.local_gas_station_rounded,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        station.name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        '${station.district} • ${station.address}',
                        style: const TextStyle(
                          color: Color(0xFF667477),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => setState(() => _selected = null),
                  icon: const Icon(Icons.close_rounded),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                _pill(
                  Icons.people_alt_rounded,
                  _crowdText(station.crowd),
                  color,
                ),
                const SizedBox(width: 8),
                _pill(
                  Icons.near_me_outlined,
                  _distanceText(station),
                  const Color(0xFF53666A),
                ),
                const Spacer(),
                FilledButton.icon(
                  onPressed: () => _navigateTo(station),
                  icon: const Icon(Icons.navigation_rounded),
                  label: const Text('مسیریابی'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _pill(IconData icon, String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 4),
          Text(
            text,
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.w700,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
