# Pump Live v3

- Bottom navigation restored
- Home + map + report + profile
- OpenStreetMap + GPS
- Fetches fuel stations from OpenStreetMap Overpass for the District 1/3 pilot area
- Curated fallback includes Shahid Mahallati, Niavaran, Velenjak, Aghdasieh, Bagh Ferdos, and District 3 stations
- Navigation chooser: Google Maps, Waze, Neshan, Balad
- Crowd status remains demo until backend phase
