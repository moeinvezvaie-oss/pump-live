
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const PumpLiveApp());

class PumpLiveApp extends StatelessWidget {
  const PumpLiveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'پمپ لایو',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF00A99D)),
        scaffoldBackgroundColor: const Color(0xFFF7F9F9),
      ),
      home: const MainShell(),
    );
  }
}

enum CrowdLevel { quiet, medium, busy, veryBusy }

class Station {
  final String id;
  final String name;
  final String district;
  final String address;
  final double lat;
  final double lon;
  final CrowdLevel crowd;
  final bool liveFromMap;

  const Station({
    required this.id,
    required this.name,
    required this.district,
    required this.address,
    required this.lat,
    required this.lon,
    required this.crowd,
    this.liveFromMap = false,
  });
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;
  final _titles = const ['خانه', 'نقشه', 'گزارش', 'پروفایل'];

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onOpenMap: () => setState(() => _index = 1)),
      const MapPage(),
      const ReportPage(),
      const ProfilePage(),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            _index == 0 ? 'پمپ لایو' : _titles[_index],
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
          centerTitle: true,
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
        ),
        body: IndexedStack(index: _index, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() => _index = i),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home_rounded),
              label: 'خانه',
            ),
            NavigationDestination(
              icon: Icon(Icons.map_outlined),
              selectedIcon: Icon(Icons.map_rounded),
              label: 'نقشه',
            ),
            NavigationDestination(
              icon: Icon(Icons.add_chart_outlined),
              selectedIcon: Icon(Icons.add_chart_rounded),
              label: 'گزارش',
            ),
            NavigationDestination(
              icon: Icon(Icons.person_outline_rounded),
              selectedIcon: Icon(Icons.person_rounded),
              label: 'پروفایل',
            ),
          ],
        ),
      ),
    );
  }
}

class StationRepository {
  static const fallback = <Station>[
    Station(id:'134',name:'جایگاه ۱۳۴ اقدسیه',district:'منطقه ۱',address:'پاسداران شمالی، محدوده اقدسیه',lat:35.802296,lon:51.473480,crowd:CrowdLevel.medium),
    Station(id:'139',name:'جایگاه ۱۳۹ باغ فردوس',district:'منطقه ۱',address:'ولیعصر، محدوده باغ فردوس',lat:35.805839,lon:51.422919,crowd:CrowdLevel.busy),
    Station(id:'148',name:'پمپ بنزین ولنجک',district:'منطقه ۱',address:'بزرگراه چمران، ولنجک',lat:35.792859,lon:51.406328,crowd:CrowdLevel.quiet),
    Station(id:'niavaran',name:'پمپ بنزین نیاوران',district:'منطقه ۱',address:'خیابان باهنر، نیاوران',lat:35.8112,lon:51.4565,crowd:CrowdLevel.medium),
    Station(id:'196',name:'جایگاه ۱۹۶ شهید محلاتی',district:'منطقه ۱',address:'شهرک شهید محلاتی',lat:35.8074,lon:51.5038,crowd:CrowdLevel.busy),
    Station(id:'206',name:'جایگاه ۲۰۶',district:'منطقه ۱',address:'بلوار دانشجو، شمال تهران',lat:35.8115,lon:51.3940,crowd:CrowdLevel.medium),
    Station(id:'106',name:'جایگاه شریعتی',district:'منطقه ۳',address:'شریعتی، بالاتر از میرداماد',lat:35.7678,lon:51.4486,crowd:CrowdLevel.medium),
    Station(id:'127',name:'جایگاه پاسداران - دولت',district:'منطقه ۳',address:'پاسداران، محدوده دولت',lat:35.7710,lon:51.4635,crowd:CrowdLevel.busy),
    Station(id:'129',name:'جایگاه پاسداران',district:'منطقه ۳',address:'پاسداران، محدوده گلستان',lat:35.7770,lon:51.4645,crowd:CrowdLevel.busy),
    Station(id:'147',name:'پمپ بنزین آفریقا',district:'منطقه ۳',address:'بلوار نلسون ماندلا، بالاتر از ظفر',lat:35.769938,lon:51.420563,crowd:CrowdLevel.veryBusy),
    Station(id:'shariati-park',name:'پمپ بنزین پارک شریعتی',district:'منطقه ۳',address:'خیابان شریعتی',lat:35.748438,lon:51.448938,crowd:CrowdLevel.medium),
  ];

  static Future<List<Station>> fetchNorthTehranStations() async {
    const query = '''
[out:json][timeout:20];
(
  node["amenity"="fuel"](35.785,51.385,35.840,51.520);
  way["amenity"="fuel"](35.785,51.385,35.840,51.520);
  relation["amenity"="fuel"](35.785,51.385,35.840,51.520);
  node["amenity"="fuel"](35.735,51.395,35.785,51.490);
  way["amenity"="fuel"](35.735,51.395,35.785,51.490);
  relation["amenity"="fuel"](35.735,51.395,35.785,51.490);
);
out center tags;
''';

    try {
      final response = await http
          .post(Uri.parse('https://overpass-api.de/api/interpreter'), body: {'data': query})
          .timeout(const Duration(seconds: 25));

      if (response.statusCode != 200) return fallback;

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final elements = (data['elements'] as List?) ?? const [];
      final found = <Station>[];

      for (final raw in elements) {
        final e = raw as Map<String, dynamic>;
        final tags = (e['tags'] as Map?)?.cast<String, dynamic>() ?? {};
        final center = (e['center'] as Map?)?.cast<String, dynamic>();
        final lat = (e['lat'] ?? center?['lat']) as num?;
        final lon = (e['lon'] ?? center?['lon']) as num?;
        if (lat == null || lon == null) continue;

        final d = lat.toDouble() >= 35.785 ? 'منطقه ۱' : 'منطقه ۳';
        final name = (tags['name:fa'] ?? tags['name'] ?? 'جایگاه سوخت').toString();
        final street = (tags['addr:street'] ?? '').toString();

        found.add(Station(
          id: 'osm-${e['type']}-${e['id']}',
          name: name,
          district: d,
          address: street.isEmpty ? d : street,
          lat: lat.toDouble(),
          lon: lon.toDouble(),
          crowd: CrowdLevel.medium,
          liveFromMap: true,
        ));
      }

      final all = <Station>[...found];
      for (final f in fallback) {
        final duplicate = all.any(
          (s) => Geolocator.distanceBetween(s.lat, s.lon, f.lat, f.lon) < 250,
        );
        if (!duplicate) all.add(f);
      }

      all.sort((a, b) => a.name.compareTo(b.name));
      return all.isEmpty ? fallback : all;
    } catch (_) {
      return fallback;
    }
  }
}

class HomePage extends StatefulWidget {
  final VoidCallback onOpenMap;
  const HomePage({super.key, required this.onOpenMap});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<Station>> _future;
  String _q = '';

  @override
  void initState() {
    super.initState();
    _future = StationRepository.fetchNorthTehranStations();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Station>>(
      future: _future,
      builder: (context, snap) {
        final list = snap.data ?? StationRepository.fallback;
        final shown = list.where((s) {
          final q = _q.trim();
          return q.isEmpty || s.name.contains(q) || s.address.contains(q) || s.district.contains(q);
        }).toList();

        return RefreshIndicator(
          onRefresh: () async {
            setState(() => _future = StationRepository.fetchNorthTehranStations());
            await _future;
          },
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextField(
                onChanged: (v) => setState(() => _q = v),
                decoration: InputDecoration(
                  hintText: 'جستجوی جایگاه...',
                  prefixIcon: const Icon(Icons.search_rounded),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.map_rounded)),
                  title: const Text('جایگاه‌های منطقه ۱ و ۳', style: TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${list.length} جایگاه در نسخه آزمایشی'),
                  trailing: const Icon(Icons.chevron_left_rounded),
                  onTap: widget.onOpenMap,
                ),
              ),
              const SizedBox(height: 10),
              const Text('لیست جایگاه‌ها', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              for (final s in shown.take(30))
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.local_gas_station_rounded, color: Color(0xFF00A99D)),
                    title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text('${s.district} • ${s.address}'),
                    trailing: s.liveFromMap ? const Icon(Icons.cloud_done_outlined, size: 20) : null,
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class MapPage extends StatefulWidget {
  const MapPage({super.key});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  final MapController _mapController = MapController();
  Position? _position;
  Station? _selected;
  List<Station> _stations = StationRepository.fallback;
  bool _loadingStations = true;
  bool _locating = false;

  @override
  void initState() {
    super.initState();
    _loadStations();
    Future.microtask(_locateMe);
  }

  Future<void> _loadStations() async {
    final data = await StationRepository.fetchNorthTehranStations();
    if (!mounted) return;
    setState(() {
      _stations = data;
      _loadingStations = false;
    });
  }

  Future<void> _locateMe() async {
    if (_locating) return;
    setState(() => _locating = true);
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        setState(() => _locating = false);
        return;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        setState(() => _locating = false);
        return;
      }

      final p = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );

      if (!mounted) return;
      setState(() {
        _position = p;
        _locating = false;
      });
      _mapController.move(LatLng(p.latitude, p.longitude), 14.2);
    } catch (_) {
      if (mounted) setState(() => _locating = false);
    }
  }

  Color _crowdColor(CrowdLevel level) {
    switch (level) {
      case CrowdLevel.quiet: return const Color(0xFF19B66A);
      case CrowdLevel.medium: return const Color(0xFFFFC107);
      case CrowdLevel.busy: return const Color(0xFFFF8A00);
      case CrowdLevel.veryBusy: return const Color(0xFFE53935);
    }
  }

  String _crowdText(CrowdLevel level) {
    switch (level) {
      case CrowdLevel.quiet: return 'خلوت';
      case CrowdLevel.medium: return 'متوسط';
      case CrowdLevel.busy: return 'شلوغ';
      case CrowdLevel.veryBusy: return 'خیلی شلوغ';
    }
  }

  String _distanceText(Station station) {
    if (_position == null) return 'فاصله نامشخص';
    final meters = Geolocator.distanceBetween(
      _position!.latitude, _position!.longitude, station.lat, station.lon);
    return meters < 1000
        ? '${meters.round()} متر'
        : '${(meters / 1000).toStringAsFixed(1)} کیلومتر';
  }

  Future<void> _launch(Uri uri) async {
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('این مسیریاب روی گوشی باز نشد')),
      );
    }
  }

  Future<void> _chooseNavigator(Station s) async {
    await showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('انتخاب مسیریاب', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                _navTile('Google Maps', Icons.map_rounded, () => _launch(
                  Uri.parse('https://www.google.com/maps/dir/?api=1&destination=${s.lat},${s.lon}'))),
                _navTile('Waze', Icons.navigation_rounded, () => _launch(
                  Uri.parse('https://waze.com/ul?ll=${s.lat},${s.lon}&navigate=yes'))),
                _navTile('نشان', Icons.route_rounded, () => _launch(
                  Uri.parse('https://nshn.ir/?destination=${s.lat},${s.lon}'))),
                _navTile('بلد', Icons.directions_rounded, () => _launch(
                  Uri.parse('https://balad.ir/location?latitude=${s.lat}&longitude=${s.lon}&zoom=17'))),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _navTile(String title, IconData icon, VoidCallback onTap) {
    return ListTile(
      leading: CircleAvatar(child: Icon(icon)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      trailing: const Icon(Icons.chevron_left_rounded),
      onTap: () {
        Navigator.pop(context);
        onTap();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        FlutterMap(
          mapController: _mapController,
          options: MapOptions(
            initialCenter: const LatLng(35.785, 51.445),
            initialZoom: 12.3,
            onTap: (_, __) => setState(() => _selected = null),
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.pumplive.app',
              maxZoom: 19,
            ),
            MarkerLayer(
              markers: [
                for (final s in _stations)
                  Marker(
                    point: LatLng(s.lat, s.lon),
                    width: 52,
                    height: 52,
                    child: GestureDetector(
                      onTap: () {
                        setState(() => _selected = s);
                        _mapController.move(LatLng(s.lat, s.lon), 15.2);
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: _crowdColor(s.crowd),
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 3),
                          boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 8, offset: Offset(0, 3))],
                        ),
                        child: const Icon(Icons.local_gas_station_rounded, color: Colors.white),
                      ),
                    ),
                  ),
                if (_position != null)
                  Marker(
                    point: LatLng(_position!.latitude, _position!.longitude),
                    width: 34,
                    height: 34,
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF1976D2),
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 4),
                      ),
                    ),
                  ),
              ],
            ),
            RichAttributionWidget(
              attributions: const [TextSourceAttribution('OpenStreetMap contributors')],
            ),
          ],
        ),
        Positioned(
          top: 10,
          right: 10,
          left: 10,
          child: Card(
            elevation: 3,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              child: Row(
                children: [
                  if (_loadingStations)
                    const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  else
                    const Icon(Icons.local_gas_station_rounded),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _loadingStations
                          ? 'در حال دریافت جایگاه‌های بیشتر...'
                          : '${_stations.length} جایگاه در محدوده منطقه ۱ و ۳',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Positioned(
          left: 16,
          bottom: _selected == null ? 22 : 205,
          child: FloatingActionButton(
            heroTag: 'gps',
            onPressed: _locateMe,
            backgroundColor: Colors.white,
            foregroundColor: const Color(0xFF00A99D),
            child: _locating
                ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5))
                : const Icon(Icons.my_location_rounded),
          ),
        ),
        if (_selected != null)
          Positioned(
            right: 10,
            left: 10,
            bottom: 10,
            child: Card(
              elevation: 8,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: _crowdColor(_selected!.crowd),
                          child: const Icon(Icons.local_gas_station_rounded, color: Colors.white),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(_selected!.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                              Text('${_selected!.district} • ${_selected!.address}', style: const TextStyle(fontSize: 12)),
                            ],
                          ),
                        ),
                        IconButton(onPressed: () => setState(() => _selected = null), icon: const Icon(Icons.close_rounded)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${_crowdText(_selected!.crowd)} • ${_distanceText(_selected!)}',
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                        FilledButton.icon(
                          onPressed: () => _chooseNavigator(_selected!),
                          icon: const Icon(Icons.navigation_rounded),
                          label: const Text('مسیریابی'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    const Align(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'وضعیت شلوغی هنوز آزمایشی است.',
                        style: TextStyle(color: Color(0xFF8A5A00), fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class ReportPage extends StatelessWidget {
  const ReportPage({super.key});
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'گزارش شلوغی\n\nدر مرحله بعد به دیتابیس وصل می‌شود تا کاربران شلوغی واقعی جایگاه را گزارش کنند.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'پروفایل کاربر\n\nورود و امتیاز مشارکت در مرحله بعد اضافه می‌شود.',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
      ),
    );
  }
}
