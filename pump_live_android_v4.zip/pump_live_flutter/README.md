# Pump Live v4

Changes before database phase:
- Redesigned custom bottom navigation
- Added dedicated "Nearby" tab
- Automatically shows 5 closest fuel stations using the user's GPS
- Android native navigation chooser via Intent.createChooser
- The chooser lists installed apps capable of handling geo navigation
- Map/GPS and District 1/3 pilot data retained
