
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

void main() => runApp(const PumpLiveApp());

class PumpLiveApp extends StatelessWidget {
  const PumpLiveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'پمپ لایو',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF00A99D)),
        scaffoldBackgroundColor: const Color(0xFFF7F9F9),
      ),
      home: const MainShell(),
    );
  }
}

enum CrowdLevel { quiet, medium, busy, veryBusy }

class Station {
  final String id;
  final String name;
  final String district;
  final String address;
  final double lat;
  final double lon;
  final CrowdLevel crowd;
  final bool liveFromMap;

  const Station({
    required this.id,
    required this.name,
    required this.district,
    required this.address,
    required this.lat,
    required this.lon,
    required this.crowd,
    this.liveFromMap = false,
  });
}

class AppState extends ChangeNotifier {
  Position? position;
  List<Station> stations = StationRepository.fallback;
  bool loadingStations = true;
  bool locating = false;

  Future<void> init() async {
    await Future.wait([loadStations(), locate()]);
  }

  Future<void> loadStations() async {
    loadingStations = true;
    notifyListeners();
    stations = await StationRepository.fetchNorthTehranStations();
    loadingStations = false;
    notifyListeners();
  }

  Future<void> locate() async {
    if (locating) return;
    locating = true;
    notifyListeners();

    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        locating = false;
        notifyListeners();
        return;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        locating = false;
        notifyListeners();
        return;
      }

      position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );
    } catch (_) {
      // Keep the app usable even if location lookup fails.
    }

    locating = false;
    notifyListeners();
  }

  double? distanceMeters(Station s) {
    final p = position;
    if (p == null) return null;
    return Geolocator.distanceBetween(p.latitude, p.longitude, s.lat, s.lon);
  }

  List<Station> nearest({int count = 5}) {
    final p = position;
    if (p == null) return const [];
    final copy = [...stations];
    copy.sort((a, b) {
      final da = Geolocator.distanceBetween(p.latitude, p.longitude, a.lat, a.lon);
      final db = Geolocator.distanceBetween(p.latitude, p.longitude, b.lat, b.lon);
      return da.compareTo(db);
    });
    return copy.take(count).toList();
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final AppState app = AppState();
  int index = 0;

  @override
  void initState() {
    super.initState();
    app.init();
  }

  @override
  void dispose() {
    app.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(app: app, onOpenMap: () => setState(() => index = 2)),
      NearbyPage(app: app),
      MapPage(app: app),
      const ReportPage(),
      const ProfilePage(),
    ];

    return AnimatedBuilder(
      animation: app,
      builder: (context, _) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          body: SafeArea(
            child: IndexedStack(index: index, children: pages),
          ),
          bottomNavigationBar: PumpBottomBar(
            index: index,
            onChanged: (i) => setState(() => index = i),
          ),
        ),
      ),
    );
  }
}

class PumpBottomBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;

  const PumpBottomBar({
    super.key,
    required this.index,
    required this.onChanged,
  });

  static const items = [
    (Icons.home_rounded, 'خانه'),
    (Icons.near_me_rounded, 'نزدیک من'),
    (Icons.map_rounded, 'نقشه'),
    (Icons.add_chart_rounded, 'گزارش'),
    (Icons.person_rounded, 'پروفایل'),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 6, 12, 10),
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: const [
            BoxShadow(
              color: Color(0x1A000000),
              blurRadius: 18,
              offset: Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          children: List.generate(items.length, (i) {
            final selected = i == index;
            final item = items[i];
            return Expanded(
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => onChanged(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    color: selected ? const Color(0xFFE7F8F6) : Colors.transparent,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        item.$1,
                        size: selected ? 26 : 23,
                        color: selected
                            ? const Color(0xFF008F85)
                            : const Color(0xFF7A8588),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item.$2,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                          color: selected
                              ? const Color(0xFF008F85)
                              : const Color(0xFF7A8588),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}

class StationRepository {
  static const fallback = <Station>[
    Station(id:'134',name:'جایگاه ۱۳۴ اقدسیه',district:'منطقه ۱',address:'پاسداران شمالی، محدوده اقدسیه',lat:35.802296,lon:51.473480,crowd:CrowdLevel.medium),
    Station(id:'139',name:'جایگاه ۱۳۹ باغ فردوس',district:'منطقه ۱',address:'ولیعصر، محدوده باغ فردوس',lat:35.805839,lon:51.422919,crowd:CrowdLevel.busy),
    Station(id:'148',name:'پمپ بنزین ولنجک',district:'منطقه ۱',address:'بزرگراه چمران، ولنجک',lat:35.792859,lon:51.406328,crowd:CrowdLevel.quiet),
    Station(id:'niavaran',name:'پمپ بنزین نیاوران',district:'منطقه ۱',address:'خیابان باهنر، نیاوران',lat:35.8112,lon:51.4565,crowd:CrowdLevel.medium),
    Station(id:'196',name:'جایگاه ۱۹۶ شهید محلاتی',district:'منطقه ۱',address:'شهرک شهید محلاتی',lat:35.8074,lon:51.5038,crowd:CrowdLevel.busy),
    Station(id:'206',name:'جایگاه ۲۰۶',district:'منطقه ۱',address:'بلوار دانشجو، شمال تهران',lat:35.8115,lon:51.3940,crowd:CrowdLevel.medium),
    Station(id:'106',name:'جایگاه شریعتی',district:'منطقه ۳',address:'شریعتی، بالاتر از میرداماد',lat:35.7678,lon:51.4486,crowd:CrowdLevel.medium),
    Station(id:'127',name:'جایگاه پاسداران - دولت',district:'منطقه ۳',address:'پاسداران، محدوده دولت',lat:35.7710,lon:51.4635,crowd:CrowdLevel.busy),
    Station(id:'129',name:'جایگاه پاسداران',district:'منطقه ۳',address:'پاسداران، محدوده گلستان',lat:35.7770,lon:51.4645,crowd:CrowdLevel.busy),
    Station(id:'147',name:'پمپ بنزین آفریقا',district:'منطقه ۳',address:'بلوار نلسون ماندلا، بالاتر از ظفر',lat:35.769938,lon:51.420563,crowd:CrowdLevel.veryBusy),
    Station(id:'shariati-park',name:'پمپ بنزین پارک شریعتی',district:'منطقه ۳',address:'خیابان شریعتی',lat:35.748438,lon:51.448938,crowd:CrowdLevel.medium),
  ];

  static Future<List<Station>> fetchNorthTehranStations() async {
    const query = '''
[out:json][timeout:20];
(
  node["amenity"="fuel"](35.785,51.385,35.840,51.520);
  way["amenity"="fuel"](35.785,51.385,35.840,51.520);
  relation["amenity"="fuel"](35.785,51.385,35.840,51.520);
  node["amenity"="fuel"](35.735,51.395,35.785,51.490);
  way["amenity"="fuel"](35.735,51.395,35.785,51.490);
  relation["amenity"="fuel"](35.735,51.395,35.785,51.490);
);
out center tags;
''';

    try {
      final response = await http
          .post(Uri.parse('https://overpass-api.de/api/interpreter'), body: {'data': query})
          .timeout(const Duration(seconds: 25));

      if (response.statusCode != 200) return fallback;
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final elements = (data['elements'] as List?) ?? const [];
      final found = <Station>[];

      for (final raw in elements) {
        final e = raw as Map<String, dynamic>;
        final tags = (e['tags'] as Map?)?.cast<String, dynamic>() ?? {};
        final center = (e['center'] as Map?)?.cast<String, dynamic>();
        final lat = (e['lat'] ?? center?['lat']) as num?;
        final lon = (e['lon'] ?? center?['lon']) as num?;
        if (lat == null || lon == null) continue;

        final d = lat.toDouble() >= 35.785 ? 'منطقه ۱' : 'منطقه ۳';
        final name = (tags['name:fa'] ?? tags['name'] ?? 'جایگاه سوخت').toString();
        final street = (tags['addr:street'] ?? '').toString();

        found.add(Station(
          id: 'osm-${e['type']}-${e['id']}',
          name: name,
          district: d,
          address: street.isEmpty ? d : street,
          lat: lat.toDouble(),
          lon: lon.toDouble(),
          crowd: CrowdLevel.medium,
          liveFromMap: true,
        ));
      }

      final all = <Station>[...found];
      for (final f in fallback) {
        final duplicate = all.any(
          (s) => Geolocator.distanceBetween(s.lat, s.lon, f.lat, f.lon) < 250,
        );
        if (!duplicate) all.add(f);
      }
      return all.isEmpty ? fallback : all;
    } catch (_) {
      return fallback;
    }
  }
}

class HomePage extends StatefulWidget {
  final AppState app;
  final VoidCallback onOpenMap;
  const HomePage({super.key, required this.app, required this.onOpenMap});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String q = '';

  @override
  Widget build(BuildContext context) {
    final list = widget.app.stations.where((s) {
      final t = q.trim();
      return t.isEmpty || s.name.contains(t) || s.address.contains(t) || s.district.contains(t);
    }).toList();

    return RefreshIndicator(
      onRefresh: widget.app.loadStations,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('پمپ لایو', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          const Text('جایگاه مناسب را سریع‌تر پیدا کن', style: TextStyle(color: Color(0xFF687477))),
          const SizedBox(height: 16),
          TextField(
            onChanged: (v) => setState(() => q = v),
            decoration: InputDecoration(
              hintText: 'جستجوی جایگاه...',
              prefixIcon: const Icon(Icons.search_rounded),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _ActionCard(
                  icon: Icons.near_me_rounded,
                  title: 'نزدیک من',
                  subtitle: widget.app.position == null ? 'در حال یافتن موقعیت' : '۵ جایگاه نزدیک',
                  onTap: () {},
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _ActionCard(
                  icon: Icons.map_rounded,
                  title: 'نقشه',
                  subtitle: '${widget.app.stations.length} جایگاه',
                  onTap: widget.onOpenMap,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Text('جایگاه‌ها', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          for (final s in list.take(25))
            StationListTile(app: widget.app, station: s),
        ],
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                backgroundColor: const Color(0xFFE7F8F6),
                child: Icon(icon, color: const Color(0xFF008F85)),
              ),
              const SizedBox(height: 12),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              const SizedBox(height: 3),
              Text(subtitle, style: const TextStyle(fontSize: 12, color: Color(0xFF718083))),
            ],
          ),
        ),
      ),
    );
  }
}

class NearbyPage extends StatelessWidget {
  final AppState app;
  const NearbyPage({super.key, required this.app});

  @override
  Widget build(BuildContext context) {
    final nearest = app.nearest(count: 5);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('نزدیک من', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        const Text('۵ جایگاه نزدیک به موقعیت فعلی شما', style: TextStyle(color: Color(0xFF687477))),
        const SizedBox(height: 16),
        if (app.position == null)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  const Icon(Icons.location_searching_rounded, size: 40),
                  const SizedBox(height: 10),
                  const Text('برای نمایش نزدیک‌ترین جایگاه‌ها، موقعیت مکانی لازم است.'),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: app.locating ? null : app.locate,
                    icon: const Icon(Icons.my_location_rounded),
                    label: Text(app.locating ? 'در حال پیدا کردن...' : 'پیدا کردن موقعیت من'),
                  ),
                ],
              ),
            ),
          )
        else
          for (int i = 0; i < nearest.length; i++)
            Card(
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: const Color(0xFFE7F8F6),
                  foregroundColor: const Color(0xFF008F85),
                  child: Text('${i + 1}', style: const TextStyle(fontWeight: FontWeight.w900)),
                ),
                title: Text(nearest[i].name, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('${distanceText(app.distanceMeters(nearest[i]))} • ${nearest[i].address}'),
                trailing: IconButton(
                  icon: const Icon(Icons.navigation_rounded),
                  onPressed: () => NativeNavigator.openChooser(nearest[i]),
                ),
              ),
            ),
      ],
    );
  }
}

class StationListTile extends StatelessWidget {
  final AppState app;
  final Station station;
  const StationListTile({super.key, required this.app, required this.station});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const Icon(Icons.local_gas_station_rounded, color: Color(0xFF00A99D)),
        title: Text(station.name, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(
          '${station.district} • ${distanceText(app.distanceMeters(station))}',
        ),
        trailing: const Icon(Icons.chevron_left_rounded),
      ),
    );
  }
}

class NativeNavigator {
  static const _channel = MethodChannel('pump_live/navigation');

  static Future<void> openChooser(Station s) async {
    try {
      await _channel.invokeMethod('openNavigationChooser', {
        'lat': s.lat,
        'lon': s.lon,
        'label': s.name,
      });
    } catch (_) {
      // Native side shows the Android chooser when available.
    }
  }
}

String distanceText(double? meters) {
  if (meters == null) return 'فاصله نامشخص';
  return meters < 1000
      ? '${meters.round()} متر'
      : '${(meters / 1000).toStringAsFixed(1)} کیلومتر';
}

class MapPage extends StatefulWidget {
  final AppState app;
  const MapPage({super.key, required this.app});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  final MapController controller = MapController();
  Station? selected;

  Color crowdColor(CrowdLevel level) {
    switch (level) {
      case CrowdLevel.quiet: return const Color(0xFF19B66A);
      case CrowdLevel.medium: return const Color(0xFFFFC107);
      case CrowdLevel.busy: return const Color(0xFFFF8A00);
      case CrowdLevel.veryBusy: return const Color(0xFFE53935);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.app.position;
    return Stack(
      children: [
        FlutterMap(
          mapController: controller,
          options: MapOptions(
            initialCenter: const LatLng(35.785, 51.445),
            initialZoom: 12.3,
            onTap: (_, __) => setState(() => selected = null),
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.pumplive.app',
              maxZoom: 19,
            ),
            MarkerLayer(
              markers: [
                for (final s in widget.app.stations)
                  Marker(
                    point: LatLng(s.lat, s.lon),
                    width: 50,
                    height: 50,
                    child: GestureDetector(
                      onTap: () {
                        setState(() => selected = s);
                        controller.move(LatLng(s.lat, s.lon), 15.2);
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: crowdColor(s.crowd),
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 3),
                          boxShadow: const [
                            BoxShadow(color: Color(0x33000000), blurRadius: 8, offset: Offset(0, 3)),
                          ],
                        ),
                        child: const Icon(Icons.local_gas_station_rounded, color: Colors.white),
                      ),
                    ),
                  ),
                if (p != null)
                  Marker(
                    point: LatLng(p.latitude, p.longitude),
                    width: 34,
                    height: 34,
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF1976D2),
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 4),
                      ),
                    ),
                  ),
              ],
            ),
            RichAttributionWidget(
              attributions: const [TextSourceAttribution('OpenStreetMap contributors')],
            ),
          ],
        ),
        Positioned(
          top: 12,
          right: 12,
          left: 12,
          child: Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(
                children: [
                  const Icon(Icons.local_gas_station_rounded),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      widget.app.loadingStations
                          ? 'در حال دریافت جایگاه‌ها...'
                          : '${widget.app.stations.length} جایگاه در محدوده آزمایشی',
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Positioned(
          left: 16,
          bottom: selected == null ? 20 : 185,
          child: FloatingActionButton(
            heroTag: 'gps',
            onPressed: () async {
              await widget.app.locate();
              final pos = widget.app.position;
              if (pos != null) controller.move(LatLng(pos.latitude, pos.longitude), 14.3);
            },
            backgroundColor: Colors.white,
            foregroundColor: const Color(0xFF00A99D),
            child: widget.app.locating
                ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5))
                : const Icon(Icons.my_location_rounded),
          ),
        ),
        if (selected != null)
          Positioned(
            right: 12,
            left: 12,
            bottom: 10,
            child: Card(
              elevation: 8,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: crowdColor(selected!.crowd),
                          child: const Icon(Icons.local_gas_station_rounded, color: Colors.white),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(selected!.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                              Text('${selected!.district} • ${selected!.address}', style: const TextStyle(fontSize: 12)),
                              const SizedBox(height: 3),
                              Text(distanceText(widget.app.distanceMeters(selected!)), style: const TextStyle(fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                        IconButton(
                          onPressed: () => setState(() => selected = null),
                          icon: const Icon(Icons.close_rounded),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: () => NativeNavigator.openChooser(selected!),
                        icon: const Icon(Icons.navigation_rounded),
                        label: const Text('مسیریابی'),
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'وضعیت شلوغی هنوز آزمایشی است.',
                      style: TextStyle(color: Color(0xFF8A5A00), fontSize: 11),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class ReportPage extends StatelessWidget {
  const ReportPage({super.key});
  @override
  Widget build(BuildContext context) => const Center(
    child: Padding(
      padding: EdgeInsets.all(24),
      child: Text(
        'گزارش شلوغی\n\nدر مرحله بعد به دیتابیس وصل می‌شود.',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
      ),
    ),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => const Center(
    child: Text(
      'پروفایل کاربر\n\nورود و امتیاز مشارکت در مرحله بعد اضافه می‌شود.',
      textAlign: TextAlign.center,
      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
    ),
  );
}
