# Pump Live V5

- Supabase-backed stations
- Live crowd status
- Anonymous crowd reporting
- Server-side proximity validation
- Local anonymous device identifier
- Map, GPS, nearest five, and Android native navigation chooser retained
