
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

const supabaseUrl = 'https://ryvrgpsmojjgefchoknr.supabase.co';
const supabasePublishableKey = 'sb_publishable_jhJNRczbpnK8okh2k1w2Ew_c63tjMZr';

void main() => runApp(const PumpLiveApp());

class PumpLiveApp extends StatelessWidget {
  const PumpLiveApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'پمپ لایو',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF00A99D)),
        scaffoldBackgroundColor: const Color(0xFFF7F9F9),
      ),
      home: const MainShell(),
    );
  }
}

enum CrowdLevel { quiet, medium, busy, veryBusy, unknown }

extension CrowdLevelX on CrowdLevel {
  String get fa {
    switch (this) {
      case CrowdLevel.quiet: return 'خلوت';
      case CrowdLevel.medium: return 'متوسط';
      case CrowdLevel.busy: return 'شلوغ';
      case CrowdLevel.veryBusy: return 'خیلی شلوغ';
      case CrowdLevel.unknown: return 'اطلاعات کافی نیست';
    }
  }

  int? get reportValue {
    switch (this) {
      case CrowdLevel.quiet: return 0;
      case CrowdLevel.medium: return 1;
      case CrowdLevel.busy: return 2;
      case CrowdLevel.veryBusy: return 3;
      case CrowdLevel.unknown: return null;
    }
  }
}

CrowdLevel crowdFromDb(String? value) {
  switch (value) {
    case 'quiet': return CrowdLevel.quiet;
    case 'medium': return CrowdLevel.medium;
    case 'busy': return CrowdLevel.busy;
    case 'very_busy': return CrowdLevel.veryBusy;
    default: return CrowdLevel.unknown;
  }
}

class Station {
  final int id;
  final String name;
  final String district;
  final String address;
  final double lat;
  final double lon;
  CrowdLevel crowd;
  int reportCount;

  Station({
    required this.id,
    required this.name,
    required this.district,
    required this.address,
    required this.lat,
    required this.lon,
    this.crowd = CrowdLevel.unknown,
    this.reportCount = 0,
  });
}

class SupabaseApi {
  static Map<String, String> get headers => {
        'apikey': supabasePublishableKey,
        'Content-Type': 'application/json',
      };

  static Future<List<Station>> fetchStations() async {
    final uri = Uri.parse(
      '$supabaseUrl/rest/v1/stations?select=id,name,district,address,latitude,longitude&is_active=eq.true&order=id.asc',
    );
    final response = await http.get(uri, headers: headers).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) {
      throw Exception('stations ${response.statusCode}');
    }
    final rows = jsonDecode(response.body) as List;
    return rows.map((row) {
      final m = row as Map<String, dynamic>;
      return Station(
        id: (m['id'] as num).toInt(),
        name: (m['name'] ?? 'جایگاه سوخت').toString(),
        district: (m['district'] ?? '').toString(),
        address: (m['address'] ?? '').toString(),
        lat: (m['latitude'] as num).toDouble(),
        lon: (m['longitude'] as num).toDouble(),
      );
    }).toList();
  }

  static Future<Map<int, Map<String, dynamic>>> fetchStatuses() async {
    final uri = Uri.parse(
      '$supabaseUrl/rest/v1/station_live_status?select=station_id,crowd_status,report_count_30m,last_report_at',
    );
    final response = await http.get(uri, headers: headers).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) {
      throw Exception('status ${response.statusCode}');
    }
    final rows = jsonDecode(response.body) as List;
    final result = <int, Map<String, dynamic>>{};
    for (final row in rows) {
      final m = (row as Map).cast<String, dynamic>();
      result[(m['station_id'] as num).toInt()] = m;
    }
    return result;
  }

  static Future<void> submitReport({
    required int stationId,
    required String deviceId,
    required CrowdLevel crowd,
    required Position position,
  }) async {
    final value = crowd.reportValue;
    if (value == null) throw Exception('وضعیت نامعتبر است');

    final response = await http.post(
      Uri.parse('$supabaseUrl/rest/v1/reports'),
      headers: {...headers, 'Prefer': 'return=minimal'},
      body: jsonEncode({
        'station_id': stationId,
        'device_id': deviceId,
        'crowd_level': value,
        'latitude': position.latitude,
        'longitude': position.longitude,
        'accuracy_m': position.accuracy,
      }),
    ).timeout(const Duration(seconds: 15));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      String message = 'ثبت گزارش ناموفق بود';
      try {
        final data = jsonDecode(response.body);
        final dbMessage = (data['message'] ?? '').toString();
        if (dbMessage.contains('Too far')) {
          message = 'برای ثبت گزارش باید نزدیک جایگاه باشید.';
        } else if (dbMessage.contains('wait')) {
          message = 'کمی صبر کنید؛ برای این جایگاه به‌تازگی گزارش ثبت کرده‌اید.';
        }
      } catch (_) {}
      throw Exception(message);
    }
  }
}

class AppState extends ChangeNotifier {
  Position? position;
  List<Station> stations = [];
  bool loading = true;
  bool locating = false;
  String? error;
  String deviceId = '';

  Future<void> init() async {
    await _loadDeviceId();
    await Future.wait([loadData(), locate()]);
  }

  Future<void> _loadDeviceId() async {
    final prefs = await SharedPreferences.getInstance();
    var id = prefs.getString('anonymous_device_id');
    if (id == null || id.length < 8) {
      id = const Uuid().v4();
      await prefs.setString('anonymous_device_id', id);
    }
    deviceId = id;
  }

  Future<void> loadData() async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      final loaded = await SupabaseApi.fetchStations();
      final statuses = await SupabaseApi.fetchStatuses();
      for (final s in loaded) {
        final st = statuses[s.id];
        if (st != null) {
          s.crowd = crowdFromDb(st['crowd_status']?.toString());
          s.reportCount = (st['report_count_30m'] as num?)?.toInt() ?? 0;
        }
      }
      stations = loaded;
    } catch (_) {
      error = 'اتصال به دیتابیس برقرار نشد. دوباره تلاش کنید.';
    }
    loading = false;
    notifyListeners();
  }

  Future<void> refreshStatus() async {
    try {
      final statuses = await SupabaseApi.fetchStatuses();
      for (final s in stations) {
        final st = statuses[s.id];
        if (st != null) {
          s.crowd = crowdFromDb(st['crowd_status']?.toString());
          s.reportCount = (st['report_count_30m'] as num?)?.toInt() ?? 0;
        }
      }
      notifyListeners();
    } catch (_) {}
  }

  Future<void> locate() async {
    if (locating) return;
    locating = true;
    notifyListeners();
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        locating = false;
        notifyListeners();
        return;
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        locating = false;
        notifyListeners();
        return;
      }
      position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );
    } catch (_) {}
    locating = false;
    notifyListeners();
  }

  double? distanceMeters(Station s) {
    final p = position;
    if (p == null) return null;
    return Geolocator.distanceBetween(p.latitude, p.longitude, s.lat, s.lon);
  }

  List<Station> nearest({int count = 5}) {
    if (position == null) return const [];
    final copy = [...stations];
    copy.sort((a, b) =>
        (distanceMeters(a) ?? double.infinity).compareTo(distanceMeters(b) ?? double.infinity));
    return copy.take(count).toList();
  }

  Future<void> report(Station station, CrowdLevel level) async {
    if (position == null) await locate();
    final p = position;
    if (p == null) throw Exception('ابتدا موقعیت مکانی شما باید پیدا شود.');
    if (deviceId.isEmpty) await _loadDeviceId();
    await SupabaseApi.submitReport(
      stationId: station.id,
      deviceId: deviceId,
      crowd: level,
      position: p,
    );
    await refreshStatus();
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final app = AppState();
  int index = 0;

  @override
  void initState() {
    super.initState();
    app.init();
  }

  @override
  void dispose() {
    app.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(app: app),
      NearbyPage(app: app),
      MapPage(app: app),
      ReportPage(app: app),
      const ProfilePage(),
    ];
    return AnimatedBuilder(
      animation: app,
      builder: (context, _) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          body: SafeArea(child: IndexedStack(index: index, children: pages)),
          bottomNavigationBar: PumpBottomBar(
            index: index,
            onChanged: (i) => setState(() => index = i),
          ),
        ),
      ),
    );
  }
}

class PumpBottomBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onChanged;
  const PumpBottomBar({super.key, required this.index, required this.onChanged});

  static const items = [
    (Icons.home_rounded, 'خانه'),
    (Icons.near_me_rounded, 'نزدیک من'),
    (Icons.map_rounded, 'نقشه'),
    (Icons.add_chart_rounded, 'گزارش'),
    (Icons.person_rounded, 'پروفایل'),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 6, 12, 10),
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: const [
            BoxShadow(color: Color(0x1A000000), blurRadius: 18, offset: Offset(0, 6)),
          ],
        ),
        child: Row(
          children: List.generate(items.length, (i) {
            final selected = i == index;
            final item = items[i];
            return Expanded(
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => onChanged(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    color: selected ? const Color(0xFFE7F8F6) : Colors.transparent,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(item.$1,
                          size: selected ? 26 : 23,
                          color: selected ? const Color(0xFF008F85) : const Color(0xFF7A8588)),
                      const SizedBox(height: 4),
                      Text(item.$2,
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                            color: selected ? const Color(0xFF008F85) : const Color(0xFF7A8588),
                          )),
                    ],
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}

Color crowdColor(CrowdLevel level) {
  switch (level) {
    case CrowdLevel.quiet: return const Color(0xFF19B66A);
    case CrowdLevel.medium: return const Color(0xFFFFC107);
    case CrowdLevel.busy: return const Color(0xFFFF8A00);
    case CrowdLevel.veryBusy: return const Color(0xFFE53935);
    case CrowdLevel.unknown: return const Color(0xFF9AA4A6);
  }
}

String distanceText(double? meters) {
  if (meters == null) return 'فاصله نامشخص';
  return meters < 1000 ? '${meters.round()} متر' : '${(meters / 1000).toStringAsFixed(1)} کیلومتر';
}

class HomePage extends StatelessWidget {
  final AppState app;
  const HomePage({super.key, required this.app});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: app.loadData,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('پمپ لایو', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          const Text('وضعیت جایگاه‌ها با گزارش کاربران', style: TextStyle(color: Color(0xFF687477))),
          const SizedBox(height: 14),
          if (app.loading) const LinearProgressIndicator(),
          if (app.error != null)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    const Icon(Icons.cloud_off_rounded),
                    const SizedBox(width: 8),
                    Expanded(child: Text(app.error!)),
                    TextButton(onPressed: app.loadData, child: const Text('تلاش مجدد')),
                  ],
                ),
              ),
            ),
          Card(
            color: const Color(0xFFEAF8F6),
            child: const Padding(
              padding: EdgeInsets.all(14),
              child: Row(
                children: [
                  Icon(Icons.cloud_done_rounded, color: Color(0xFF008F85)),
                  SizedBox(width: 10),
                  Expanded(child: Text('V5 به دیتابیس واقعی Pump Live متصل است.', style: TextStyle(fontWeight: FontWeight.w700))),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          for (final s in app.stations) StationListTile(app: app, station: s),
        ],
      ),
    );
  }
}

class StationListTile extends StatelessWidget {
  final AppState app;
  final Station station;
  const StationListTile({super.key, required this.app, required this.station});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: crowdColor(station.crowd),
          child: const Icon(Icons.local_gas_station_rounded, color: Colors.white),
        ),
        title: Text(station.name, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${station.crowd.fa} • ${distanceText(app.distanceMeters(station))}'),
        trailing: Text('${station.reportCount} گزارش', style: const TextStyle(fontSize: 11)),
        onTap: () => showStationSheet(context, app, station),
      ),
    );
  }
}

class NearbyPage extends StatelessWidget {
  final AppState app;
  const NearbyPage({super.key, required this.app});

  @override
  Widget build(BuildContext context) {
    final nearest = app.nearest(count: 5);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('نزدیک من', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
        const SizedBox(height: 16),
        if (app.position == null)
          FilledButton.icon(
            onPressed: app.locate,
            icon: const Icon(Icons.my_location_rounded),
            label: const Text('پیدا کردن موقعیت من'),
          )
        else
          for (int i = 0; i < nearest.length; i++)
            Card(
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: crowdColor(nearest[i].crowd),
                  foregroundColor: Colors.white,
                  child: Text('${i + 1}', style: const TextStyle(fontWeight: FontWeight.w900)),
                ),
                title: Text(nearest[i].name, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('${distanceText(app.distanceMeters(nearest[i]))} • ${nearest[i].crowd.fa}'),
                onTap: () => showStationSheet(context, app, nearest[i]),
              ),
            ),
      ],
    );
  }
}

class NativeNavigator {
  static const _channel = MethodChannel('pump_live/navigation');

  static Future<void> openChooser(Station s) async {
    await _channel.invokeMethod('openNavigationChooser', {
      'lat': s.lat,
      'lon': s.lon,
      'label': s.name,
    });
  }
}

Future<void> showStationSheet(BuildContext context, AppState app, Station station) async {
  await showModalBottomSheet(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (sheetContext) => Directionality(
      textDirection: TextDirection.rtl,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(station.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            Text('${station.district} • ${station.address}'),
            const SizedBox(height: 8),
            Text('وضعیت فعلی: ${station.crowd.fa} • ${station.reportCount} گزارش در ۳۰ دقیقه'),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () => NativeNavigator.openChooser(station),
              icon: const Icon(Icons.navigation_rounded),
              label: const Text('مسیریابی'),
            ),
            const SizedBox(height: 10),
            const Text('الان این جایگاه چقدر شلوغ است؟', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: [
                for (final level in [CrowdLevel.quiet, CrowdLevel.medium, CrowdLevel.busy, CrowdLevel.veryBusy])
                  OutlinedButton(
                    onPressed: () async {
                      try {
                        await app.report(station, level);
                        if (sheetContext.mounted) {
                          Navigator.pop(sheetContext);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('گزارش «${level.fa}» ثبت شد. ممنون!')),
                          );
                        }
                      } catch (e) {
                        if (sheetContext.mounted) {
                          ScaffoldMessenger.of(sheetContext).showSnackBar(
                            SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
                          );
                        }
                      }
                    },
                    child: Text(level.fa),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'سرور فاصله شما تا جایگاه را بررسی می‌کند تا گزارش اشتباه کمتر شود.',
              style: TextStyle(fontSize: 11, color: Color(0xFF687477)),
            ),
          ],
        ),
      ),
    ),
  );
}

class MapPage extends StatefulWidget {
  final AppState app;
  const MapPage({super.key, required this.app});
  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  final controller = MapController();
  Station? selected;

  @override
  Widget build(BuildContext context) {
    final p = widget.app.position;
    return Stack(
      children: [
        FlutterMap(
          mapController: controller,
          options: MapOptions(
            initialCenter: const LatLng(35.785, 51.445),
            initialZoom: 12.3,
            onTap: (_, __) => setState(() => selected = null),
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.pumplive.app',
              maxZoom: 19,
            ),
            MarkerLayer(
              markers: [
                for (final s in widget.app.stations)
                  Marker(
                    point: LatLng(s.lat, s.lon),
                    width: 50,
                    height: 50,
                    child: GestureDetector(
                      onTap: () {
                        setState(() => selected = s);
                        controller.move(LatLng(s.lat, s.lon), 15.2);
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: crowdColor(s.crowd),
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 3),
                        ),
                        child: const Icon(Icons.local_gas_station_rounded, color: Colors.white),
                      ),
                    ),
                  ),
                if (p != null)
                  Marker(
                    point: LatLng(p.latitude, p.longitude),
                    width: 34,
                    height: 34,
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF1976D2),
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 4),
                      ),
                    ),
                  ),
              ],
            ),
            RichAttributionWidget(
              attributions: const [TextSourceAttribution('OpenStreetMap contributors')],
            ),
          ],
        ),
        Positioned(
          top: 12,
          right: 12,
          left: 12,
          child: Card(
            child: ListTile(
              leading: const Icon(Icons.cloud_done_rounded, color: Color(0xFF008F85)),
              title: Text('${widget.app.stations.length} جایگاه • داده از Pump Live'),
              trailing: IconButton(onPressed: widget.app.refreshStatus, icon: const Icon(Icons.refresh_rounded)),
            ),
          ),
        ),
        Positioned(
          left: 16,
          bottom: selected == null ? 20 : 110,
          child: FloatingActionButton(
            heroTag: 'gps',
            onPressed: () async {
              await widget.app.locate();
              final pos = widget.app.position;
              if (pos != null) controller.move(LatLng(pos.latitude, pos.longitude), 14.3);
            },
            child: const Icon(Icons.my_location_rounded),
          ),
        ),
        if (selected != null)
          Positioned(
            right: 12,
            left: 12,
            bottom: 10,
            child: Card(
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: crowdColor(selected!.crowd),
                  child: const Icon(Icons.local_gas_station_rounded, color: Colors.white),
                ),
                title: Text(selected!.name, style: const TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text('${selected!.crowd.fa} • ${distanceText(widget.app.distanceMeters(selected!))}'),
                trailing: FilledButton(
                  onPressed: () => showStationSheet(context, widget.app, selected!),
                  child: const Text('جزئیات'),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class ReportPage extends StatelessWidget {
  final AppState app;
  const ReportPage({super.key, required this.app});

  @override
  Widget build(BuildContext context) {
    final nearest = app.nearest(count: 5);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('گزارش شلوغی', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        const Text('یکی از جایگاه‌های نزدیک را انتخاب کنید.', style: TextStyle(color: Color(0xFF687477))),
        const SizedBox(height: 16),
        if (app.position == null)
          FilledButton.icon(
            onPressed: app.locate,
            icon: const Icon(Icons.my_location_rounded),
            label: const Text('پیدا کردن موقعیت من'),
          )
        else
          for (final s in nearest)
            Card(
              child: ListTile(
                title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(distanceText(app.distanceMeters(s))),
                trailing: const Icon(Icons.chevron_left_rounded),
                onTap: () => showStationSheet(context, app, s),
              ),
            ),
      ],
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'Pump Live V5\n\nگزارش‌ها فعلاً به‌صورت ناشناس ثبت می‌شوند.\nورود کاربر و امتیازدهی در مرحله بعد اضافه می‌شود.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}
